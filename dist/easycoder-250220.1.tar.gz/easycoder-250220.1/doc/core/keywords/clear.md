# clear

## Syntax:
`clear {variable}`

## Examples:
`clear Flag`

## Description:
`clear` sets the value of the [variable](variable.md) to the Boolean value `false`. See also [set](set.md).

Next: [close](close.md)  
Prev: [begin](begin.md)

[Back](../../README.md)
