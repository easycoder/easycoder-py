## ellipse

## Syntax:
`ellipse {name}`

## Examples:
`ellipse Circle`

## Description:
Declares an ellipse variable. This will be attached to a rendered ellipse and used to pass commands to it. See also [image](image.md), [rectangle](rectangle.md) and [text](text.md).

Next: [image](image.md)  
Prev: [create](create.md)

[Back](../../README.md)
