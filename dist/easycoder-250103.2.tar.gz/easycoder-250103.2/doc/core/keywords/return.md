# return

## Syntax:
`return`
## Examples:
`return`

## Description:
Return from a subroutine. See [gosub](gosub.md).

Next: [save](save.md)  
Prev: [replace](replace.md)

[Back](../../README.md)
