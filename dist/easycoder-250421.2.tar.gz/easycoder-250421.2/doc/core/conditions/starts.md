# starts

## Syntax:
`{value} starts with {text}`

## Examples:
``if Value starts with `!` stop` ``

## Description:
Tests if the value starts with the given text.

Next: [string](string.md)  
Prev: [odd](odd.md)

[Back](../../README.md)
