from easycoder import Program

Program('scripts/rbr_ui.ecs').start()
