# load

## Syntax:
`load {variable} from {path}`

## Examples:
``load Data from `mydata.txt` ``  
`load Data from Path`

## Description:
Loads the contents of a file into a variable. See also [save](save.md).

Next: [lock](lock.md)  
Prev: [init](init.md)

[Back](../../README.md)
