# modification

## Syntax:
`[the] modification time of {filename}`

## Examples:
``print the modification time of `myfile.txt` ``

## Description:
Gets the timestamp of when the named file was last modified.

Next: [modulo](modulo.md)  
Prev: [memory](memory.md)

[Back](../../README.md)
