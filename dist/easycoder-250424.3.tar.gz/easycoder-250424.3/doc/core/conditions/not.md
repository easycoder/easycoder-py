# not

## Syntax:
`{value} is not {second value}`

## Examples:
`if Value is not 100 stop`

## Description:
Tests if the value is not the same as the second value.

Next: [object](obect.md)  
Prev: [none](none.md)

[Back](../../README.md)
