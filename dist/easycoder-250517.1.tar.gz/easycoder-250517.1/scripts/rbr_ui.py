from easycoder import Program

Program('rbr-ui.ecs').start()
