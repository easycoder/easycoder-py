# cat

## Syntax:
`[the] cat [of] {value} [and/cat] {value}...`

## Examples:
``print `the cat of `My age is` cat 50` ``  
``print the cat of `one` and newline and `two` and newline and `three`` ``

## Description:
Catenates string elements. 

Next: [cos](cos.md)  
Prev: [args](args.md)

[Back](../../README.md)
