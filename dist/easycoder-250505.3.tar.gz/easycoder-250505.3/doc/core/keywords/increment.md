# increment

## Syntax:
`increment {variable}`

## Examples:
`increment N`

## Description:
Add 1 to the value of the variable. See also [decrement](decrement.md).

Next: [index](index.md)  
Prev: [import](import.md)

[Back](../../README.md)
