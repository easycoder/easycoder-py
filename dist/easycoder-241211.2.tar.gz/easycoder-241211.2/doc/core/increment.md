## Syntax:
`increment {variable}`

## Examples:
`increment N`

## Description:
Add 1 to the value of the variable. See also [decrement](decrement.md).

Next: [index](index.md)  
Prev: [if](if.md)

[Back](../core.md)
