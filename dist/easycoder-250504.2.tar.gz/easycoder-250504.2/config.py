from easycoder import Program

Program('config.ecs').start()
