# elements

## Syntax:
`element of {variable}`]

## Examples:
`print the elements of Array`

## Description:
Returns the count of the number of elements in this variable, which are accessed by the [index](../keywords/index.md) keyword.

Next: [empty](empty.md)  
Prev: [element](element.md)

[Back](../../README.md)
