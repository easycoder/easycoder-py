from easycoder import Program

Program('rbrconf.ecs').start()
