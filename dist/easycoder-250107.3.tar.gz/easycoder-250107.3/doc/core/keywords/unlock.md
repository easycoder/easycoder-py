# ulock

## Syntax:
`unlock {variable}`

## Examples:
`lock Status`

## Description:
Unlocks a locked variable to allow it to be modified. See also [lock](lock.md).

Next: [lock](lock.md)  
Prev: [init](init.md)

[Back](../../README.md)
