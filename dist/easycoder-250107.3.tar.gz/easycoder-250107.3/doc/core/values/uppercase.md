# uppercase

## Syntax:
`uppercase {text}`

## Examples:
``print uppercase MixedCase` ``

## Description:
Converts all the characters in a string into upper case.

Next: [value](value.md)  
Prev: [today](today.md)

[Back](../../README.md)
