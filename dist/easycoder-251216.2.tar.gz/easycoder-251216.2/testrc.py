#!/bin/python3

import os
from easycoder import Program

os.chdir('/home/graham/dev/rbr/roombyroom/Controller/ui')
Program('rbrconf.ecs').start()
