## Syntax:
`script {name}`
## Examples:
`script Calculate`

## Description:
Provides a name for the script. Note that `name` is literal text, not a script variable.

Next: [set](set.md)  
Prev: [return](return.md)

[Back](../README.md)
