#!/bin/python3

from easycoder import Program

Program('../../rbr/rbrconf.ecs').start()
