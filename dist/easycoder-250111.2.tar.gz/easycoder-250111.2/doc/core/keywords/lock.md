# lock

## Syntax:
`lock {variable}`

## Examples:
`lock Status`

## Description:
Locks a variable to prevent it being modified. See also [unlock](unlock.md).

Next: [lock](lock.md)  
Prev: [init](init.md)

[Back](../../README.md)
