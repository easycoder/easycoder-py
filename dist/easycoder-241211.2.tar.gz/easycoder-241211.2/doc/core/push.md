## Syntax:
`push {variable} to/onto {stack}`
## Examples:
``push `Hello, world!` to DataStack``  
`push Value onto ValueStack`

## Description:
Push something onto the specified [stack](stack.md).

Next: [put](put.md)  
Prev: [print](print.md)

[Back](../README.md)
