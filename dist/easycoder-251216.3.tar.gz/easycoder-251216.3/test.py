#!/bin/python3

import os
from easycoder import Program

os.chdir('/home/graham/dev/easycoder/easycoder-py/tests')
Program('debug tests.ecs').start()
