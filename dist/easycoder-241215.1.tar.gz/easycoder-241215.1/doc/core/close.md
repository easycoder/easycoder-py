## Syntax:
`close {file}`
## Examples:
`close InputFile`
## Description:
Close the file identified by the `{file}` variable. See `file`, `open`, `read` and `write`. 

Next: [create](create.md)  
Prev: [clear](clear.md)

[Back](../README.md)
