## Syntax:
`return`
## Examples:
`return`

## Description:
Return from a subroutine. See [gosub](gosub.md).

Next: [script](script.md)  
Prev: [replace](replace.md)

[Back](../core.md)
