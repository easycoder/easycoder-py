from easycoder import Program

Program('test.ecs').start()
