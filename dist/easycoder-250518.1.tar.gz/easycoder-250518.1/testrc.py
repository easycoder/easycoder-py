from easycoder import Program

Program('../../rbr/rbrconf.ecs').start()
