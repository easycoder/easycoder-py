## close

## Syntax:
`close window`

## Examples:
`close window`

## Description:
Close the window. This will also terminate the **_EasyCoder_** script.

Next: [combobox](combobox.md)  
Prev: [clear](clear.md)

[Back](../../README.md)
