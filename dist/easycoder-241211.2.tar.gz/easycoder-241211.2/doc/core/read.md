## Syntax:
`read {value} from {file}`
## Examples:
`read Value from MyFile`

## Description:
Read a value from a [file](file.md). See [open](open.md), [write](write.md) and [close](close.md).

Next: [replace](replace.md)  
Prev: [put](put.md)

[Back](../core.md)
