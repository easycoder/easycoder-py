# send

## Syntax:
`send {message} to {module}`
## Examples:
``send `No errors` to Main``

## Description:
Sends a message to another script. See [on message](on.md).

Next: [set](set.md)  
Prev: [script](script.md)

[Back](../../README.md)
