#!/bin/python3

import os
from easycoder import Program

os.chdir('/home/graham/dev/easycoder/easycoder-py')
Program('debug scripts/tests-dbg.ecs').start()
