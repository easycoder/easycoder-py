## Syntax:
`write {value} to {file}`

## Example:
`write Value to MyFile`

## Description:
Write a value to a [file](file.md). See [open](open.md), [read](read.md) and [close](close.md).

Next: [add](add.md)  
Prev: [while](while.md)

[Back](../../README.md)
