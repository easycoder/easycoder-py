# exit

## Syntax:
`exit`
## Examples:
`exit`
## Description:
Terminate the program.

Next: [file](file.md)  
Prev: [divide](divide.md)

[Back](../../README.md)
