#!/bin/python3

from easycoder import Program

Program('debug /home/graham/dev/easycoder/easycoder-py/scripts/tests.ecs').start()
