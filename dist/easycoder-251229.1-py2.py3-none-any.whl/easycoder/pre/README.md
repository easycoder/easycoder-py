# 'Pre' version of EasyCoder

The code in this directory is a version of EasyCoder that will run on Python versions lower than 10. It is missing more recent improvements such as the use of annotations.
