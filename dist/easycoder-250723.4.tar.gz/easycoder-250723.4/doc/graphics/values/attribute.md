# attribute

## Syntax:
`attribute {key} of {element}`

## Examples:
``attribute `width` of BigBox` ``

## Description:
Gets the named attribute of a graphic element. 

Next: [window](window.md)  
Prev: [window](window.md)

[Back](../../README.md)
