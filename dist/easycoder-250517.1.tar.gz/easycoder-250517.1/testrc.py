from easycoder import Program

Program('scripts/rbrconf.ecs').start()
