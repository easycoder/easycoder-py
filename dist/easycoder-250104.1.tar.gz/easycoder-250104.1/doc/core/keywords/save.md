# save

## Syntax:
`save {value} to {filename}`

## Examples:
``save Data to `mydata.txt` ``  
`save Data to FileName`

## Description:
Saves data to a file. See also [load](load.md).

Next: [set](set.md)  
Prev: [return](return.md)

[Back](../../README.md)
