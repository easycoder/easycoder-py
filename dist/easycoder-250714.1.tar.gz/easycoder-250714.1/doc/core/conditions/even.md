# even

## Syntax:
`{value} ends with {text}`

## Examples:
``if MyVariable ends with `#` stop` ``

## Description:
Tests if the given number is even. The inclusion of `[not]` negates the test, or you can use [odd](odd.md).

Next: [exists](exists.md)  
Prev: [ends](ends.md)

[Back](../../README.md)
